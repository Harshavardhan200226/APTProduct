-- ─────────────────────────────────────────────────────────────────────────────
-- Database & Table Setup
-- Run this once before starting the application
-- ─────────────────────────────────────────────────────────────────────────────

CREATE DATABASE IF NOT EXISTS orders_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE orders_db;

-- The main orders table
-- Hibernate will create/update it automatically (spring.jpa.hibernate.ddl-auto=update)
-- but you can also create it explicitly:

CREATE TABLE IF NOT EXISTS orders (
    id              BIGINT          NOT NULL AUTO_INCREMENT,
    customer_name   VARCHAR(150)    NOT NULL,
    product_name    VARCHAR(200)    NOT NULL,
    status          ENUM('PENDING','SHIPPED','DELIVERED') NOT NULL DEFAULT 'PENDING',
    updated_at      DATETIME(6)     NOT NULL,
    created_at      DATETIME(6)     NOT NULL,

    PRIMARY KEY (id),

    -- This index is CRITICAL for efficient polling.
    -- The polling query is: WHERE updated_at > ?
    -- Without this index it's a full table scan every second.
    INDEX idx_orders_updated_at (updated_at),
    INDEX idx_orders_status     (status)
) ENGINE=InnoDB;

-- Seed some sample data (optional)
INSERT INTO orders (customer_name, product_name, status, updated_at, created_at) VALUES
  ('Alice Johnson',  'MacBook Pro 14"',     'PENDING',   NOW(), NOW()),
  ('Bob Smith',      'Sony WH-1000XM5',     'SHIPPED',   NOW(), NOW()),
  ('Carol Williams', 'Mechanical Keyboard', 'DELIVERED', NOW(), NOW());
