package com.apt.realtime.service;

import com.apt.realtime.dto.OrderDtos.OrderChangeEvent;
import com.apt.realtime.dto.OrderDtos.OrderResponse;
import com.apt.realtime.model.Order;
import com.apt.realtime.repository.OrderRepository;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class OrderChangePollingService {

    private static final Logger log = LoggerFactory.getLogger(OrderChangePollingService.class);

    private final OrderRepository orderRepository;
    private final SseEmitterService sseEmitterService;

    private volatile LocalDateTime lastCheckedAt;
    private final Map<Long, LocalDateTime> knownOrders = new ConcurrentHashMap<>();

    public OrderChangePollingService(OrderRepository orderRepository,
                                     SseEmitterService sseEmitterService) {
        this.orderRepository   = orderRepository;
        this.sseEmitterService = sseEmitterService;
    }

    @PostConstruct
    @Transactional(readOnly = true)
    public void initialize() {
        LocalDateTime maxTimestamp = orderRepository.findMaxUpdatedAt();
        lastCheckedAt = (maxTimestamp != null)
                ? maxTimestamp.minusSeconds(1)
                : LocalDateTime.now().minusSeconds(1);

        for (Order o : orderRepository.findAll()) {
            knownOrders.put(o.getId(), o.getUpdatedAt());
        }

        log.info("Initialized. Watermark: {}. Known orders: {}", lastCheckedAt, knownOrders.size());
    }

    @Scheduled(fixedDelayString = "${app.polling.interval:1000}")
    @Transactional(readOnly = true)
    public void pollForChanges() {
        if (sseEmitterService.getActiveConnectionCount() == 0) {
            return;
        }

        List<Order> changedOrders = orderRepository.findAllUpdatedAfter(lastCheckedAt);

        if (!changedOrders.isEmpty()) {
            log.debug("Poll found {} changed order(s)", changedOrders.size());

            for (Order order : changedOrders) {
                String eventType = knownOrders.containsKey(order.getId()) ? "UPDATED" : "CREATED";
                OrderChangeEvent event = OrderChangeEvent.of(eventType, OrderResponse.from(order));
                sseEmitterService.broadcast(event);
                knownOrders.put(order.getId(), order.getUpdatedAt());
            }

            // Advance watermark to latest updatedAt seen
            LocalDateTime latest = lastCheckedAt;
            for (Order o : changedOrders) {
                if (o.getUpdatedAt().isAfter(latest)) {
                    latest = o.getUpdatedAt();
                }
            }
            lastCheckedAt = latest;
        }

        if (LocalDateTime.now().getSecond() % 5 == 0) {
            detectDeletes();
        }
    }

    private void detectDeletes() {
        Set<Long> currentIds = new HashSet<>();
        for (Order o : orderRepository.findAll()) {
            currentIds.add(o.getId());
        }

        Set<Long> deletedIds = new HashSet<>();
        for (Long id : knownOrders.keySet()) {
            if (!currentIds.contains(id)) {
                deletedIds.add(id);
            }
        }

        for (Long deletedId : deletedIds) {
            log.info("DELETE detected for orderId={}", deletedId);
            OrderResponse deletedOrder = new OrderResponse();
            deletedOrder.setId(deletedId);
            OrderChangeEvent event = OrderChangeEvent.of("DELETED", deletedOrder);
            sseEmitterService.broadcast(event);
            knownOrders.remove(deletedId);
        }
    }

    public void forceRefresh() {
        lastCheckedAt = lastCheckedAt.minusSeconds(1);
    }
}