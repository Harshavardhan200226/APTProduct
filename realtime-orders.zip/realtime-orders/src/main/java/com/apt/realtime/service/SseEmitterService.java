package com.apt.realtime.service;

import com.apt.realtime.dto.OrderDtos.OrderChangeEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

@Service
public class SseEmitterService {

    private static final Logger log = LoggerFactory.getLogger(SseEmitterService.class);

    @Value("${app.sse.timeout:1800000}")
    private long sseTimeout;

    private final Map<String, SseEmitter> emitters = new ConcurrentHashMap<>();
    private final AtomicInteger totalConnections = new AtomicInteger(0);

    public SseEmitter createEmitter() {
        String clientId = UUID.randomUUID().toString();
        SseEmitter emitter = new SseEmitter(sseTimeout);

        emitters.put(clientId, emitter);
        totalConnections.incrementAndGet();
        log.info("SSE client connected [id={}] — active: {}", clientId, emitters.size());

        emitter.onCompletion(() -> removeEmitter(clientId, "completed"));
        emitter.onTimeout(()    -> removeEmitter(clientId, "timed out"));
        emitter.onError(e       -> removeEmitter(clientId, "error: " + e.getMessage()));

        try {
            emitter.send(SseEmitter.event()
                    .name("connected")
                    .data("Connected. Listening for order changes..."));
        } catch (IOException e) {
            log.warn("Failed to send initial event to client [{}]: {}", clientId, e.getMessage());
            removeEmitter(clientId, "initial send failed");
        }

        return emitter;
    }

    public void broadcast(OrderChangeEvent event) {
        if (emitters.isEmpty()) {
            log.debug("No SSE clients connected — skipping broadcast.");
            return;
        }

        log.info("Broadcasting {} event for orderId={} to {} client(s)",
                event.getEventType(), event.getOrder().getId(), emitters.size());

        emitters.forEach((clientId, emitter) -> {
            try {
                emitter.send(SseEmitter.event()
                        .name("order-update")
                        .data(event));
            } catch (IOException e) {
                log.warn("Failed to send to client [{}] — removing: {}", clientId, e.getMessage());
                removeEmitter(clientId, "send failed");
            }
        });
    }

    @Scheduled(fixedDelayString = "${app.sse.heartbeat-interval:15000}")
    public void sendHeartbeat() {
        if (emitters.isEmpty()) return;

        String heartbeat = "ping@" + LocalDateTime.now();
        emitters.forEach((clientId, emitter) -> {
            try {
                emitter.send(SseEmitter.event().name("heartbeat").data(heartbeat));
            } catch (IOException e) {
                removeEmitter(clientId, "heartbeat failed");
            }
        });
        log.debug("Heartbeat sent to {} client(s)", emitters.size());
    }

    public int getActiveConnectionCount() {
        return emitters.size();
    }

    public int getTotalConnectionCount() {
        return totalConnections.get();
    }

    private void removeEmitter(String clientId, String reason) {
        if (emitters.remove(clientId) != null) {
            log.info("SSE client disconnected [id={}, reason={}] — active: {}", clientId, reason, emitters.size());
        }
    }
}