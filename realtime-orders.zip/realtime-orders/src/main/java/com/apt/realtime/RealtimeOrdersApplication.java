package com.apt.realtime;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling  // enables the DB-polling scheduler
public class RealtimeOrdersApplication {

    public static void main(String[] args) {
        SpringApplication.run(RealtimeOrdersApplication.class, args);
    }
}
