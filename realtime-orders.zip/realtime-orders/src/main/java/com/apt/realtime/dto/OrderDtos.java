package com.apt.realtime.dto;

import com.apt.realtime.model.Order;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

import java.time.LocalDateTime;

public class OrderDtos {

    // ─── Inbound ───────────────────────────────────────────────────────────────

    public static class CreateOrderRequest {
        @NotBlank(message = "Customer name is required")
        private String customerName;

        @NotBlank(message = "Product name is required")
        private String productName;

        public CreateOrderRequest() {}

        public String getCustomerName() { return customerName; }
        public void setCustomerName(String customerName) { this.customerName = customerName; }
        public String getProductName() { return productName; }
        public void setProductName(String productName) { this.productName = productName; }
    }

    public static class UpdateOrderRequest {
        private String customerName;
        private String productName;

        @Pattern(regexp = "PENDING|SHIPPED|DELIVERED",
                 message = "Status must be PENDING, SHIPPED, or DELIVERED")
        private String status;

        public UpdateOrderRequest() {}

        public String getCustomerName() { return customerName; }
        public void setCustomerName(String customerName) { this.customerName = customerName; }
        public String getProductName() { return productName; }
        public void setProductName(String productName) { this.productName = productName; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
    }

    // ─── Outbound ──────────────────────────────────────────────────────────────

    public static class OrderResponse {
        private Long id;
        private String customerName;
        private String productName;
        private String status;
        private LocalDateTime updatedAt;
        private LocalDateTime createdAt;

        public OrderResponse() {}

        public static OrderResponse from(Order order) {
            OrderResponse r = new OrderResponse();
            r.id            = order.getId();
            r.customerName  = order.getCustomerName();
            r.productName   = order.getProductName();
            r.status        = order.getStatus().name();
            r.updatedAt     = order.getUpdatedAt();
            r.createdAt     = order.getCreatedAt();
            return r;
        }

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public String getCustomerName() { return customerName; }
        public void setCustomerName(String customerName) { this.customerName = customerName; }
        public String getProductName() { return productName; }
        public void setProductName(String productName) { this.productName = productName; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
        public LocalDateTime getUpdatedAt() { return updatedAt; }
        public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
        public LocalDateTime getCreatedAt() { return createdAt; }
        public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    }

    // ─── SSE Event ─────────────────────────────────────────────────────────────

    public static class OrderChangeEvent {
        private String eventType;
        private OrderResponse order;
        private LocalDateTime timestamp;

        public OrderChangeEvent() {}

        public static OrderChangeEvent of(String eventType, OrderResponse order) {
            OrderChangeEvent e = new OrderChangeEvent();
            e.eventType = eventType;
            e.order     = order;
            e.timestamp = LocalDateTime.now();
            return e;
        }

        public String getEventType() { return eventType; }
        public void setEventType(String eventType) { this.eventType = eventType; }
        public OrderResponse getOrder() { return order; }
        public void setOrder(OrderResponse order) { this.order = order; }
        public LocalDateTime getTimestamp() { return timestamp; }
        public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }
    }
}