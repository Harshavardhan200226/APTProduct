package com.apt.realtime.controller;

import com.apt.realtime.config.GlobalExceptionHandler;
import com.apt.realtime.dto.OrderDtos.*;
import com.apt.realtime.service.OrderService;
import com.apt.realtime.service.SseEmitterService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
@Slf4j
@CrossOrigin(origins = "*")   // allow browser client on any origin
public class OrderController {
	
	private static final org.slf4j.Logger log = 
		    org.slf4j.LoggerFactory.getLogger(OrderController.class);

	@Autowired
    private  OrderService orderService;
	
	@Autowired
    private SseEmitterService sseEmitterService;

    // ─── SSE Subscription ──────────────────────────────────────────────────────

    /**
     * GET /api/orders/stream
     *
     * Clients subscribe here once. From that point on they receive push events
     * for every INSERT / UPDATE / DELETE — no polling from their side.
     */
    @GetMapping(value = "/orders/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter streamOrderUpdates() {
        log.info("New SSE subscription request");
        return sseEmitterService.createEmitter();
    }

    // ─── CRUD REST Endpoints ───────────────────────────────────────────────────

    @GetMapping("/orders")
    public ResponseEntity<List<OrderResponse>> getAllOrders() {
        return ResponseEntity.ok(orderService.getAllOrders());
    }

    @GetMapping("/orders/{id}")
    public ResponseEntity<OrderResponse> getOrder(@PathVariable Long id) {
        return ResponseEntity.ok(orderService.getOrderById(id));
    }

    @PostMapping("/orders")
    public ResponseEntity<OrderResponse> createOrder(@Valid @RequestBody CreateOrderRequest request) {
        OrderResponse created = orderService.createOrder(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @PatchMapping("/orders/{id}")
    public ResponseEntity<OrderResponse> updateOrder(
            @PathVariable Long id,
            @RequestBody UpdateOrderRequest request) {
        return ResponseEntity.ok(orderService.updateOrder(id, request));
    }

    @DeleteMapping("/orders/{id}")
    public ResponseEntity<Void> deleteOrder(@PathVariable Long id) {
        orderService.deleteOrder(id);
        return ResponseEntity.noContent().build();
    }

    // ─── Health / Stats ────────────────────────────────────────────────────────

    @GetMapping("/stats")
    public ResponseEntity<Map<String, Object>> getStats() {
        return ResponseEntity.ok(Map.of(
                "activeConnections", sseEmitterService.getActiveConnectionCount(),
                "totalConnections",  sseEmitterService.getTotalConnectionCount(),
                "status",            "UP"
        ));
    }
}
