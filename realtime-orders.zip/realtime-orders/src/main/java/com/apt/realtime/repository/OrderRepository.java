package com.apt.realtime.repository;

import com.apt.realtime.model.Order;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {

    /**
     * KEY EFFICIENCY QUERY:
     * Instead of fetching ALL orders every poll cycle, we only fetch rows
     * whose updated_at is strictly after the last known timestamp.
     * The index on updated_at makes this O(changed_rows) not O(total_rows).
     */
    @Query("SELECT o FROM Order o WHERE o.updatedAt > :since ORDER BY o.updatedAt ASC")
    List<Order> findAllUpdatedAfter(@Param("since") LocalDateTime since);

    /**
     * Used on startup to get the latest timestamp so we don't
     * replay all historical events when the server restarts.
     */
    @Query("SELECT MAX(o.updatedAt) FROM Order o")
    LocalDateTime findMaxUpdatedAt();
}
