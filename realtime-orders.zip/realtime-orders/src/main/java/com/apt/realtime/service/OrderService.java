package com.apt.realtime.service;

import com.apt.realtime.dto.OrderDtos.CreateOrderRequest;
import com.apt.realtime.dto.OrderDtos.OrderResponse;
import com.apt.realtime.dto.OrderDtos.UpdateOrderRequest;
import com.apt.realtime.model.Order;
import com.apt.realtime.model.Order.OrderStatus;
import com.apt.realtime.repository.OrderRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class OrderService {

    private static final Logger log = LoggerFactory.getLogger(OrderService.class);

    private final OrderRepository orderRepository;
    private final OrderChangePollingService pollingService;

    public OrderService(OrderRepository orderRepository, OrderChangePollingService pollingService) {
        this.orderRepository = orderRepository;
        this.pollingService  = pollingService;
    }

    @Transactional(readOnly = true)
    public List<OrderResponse> getAllOrders() {
        return orderRepository.findAll()
                .stream()
                .map(OrderResponse::from)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public OrderResponse getOrderById(Long id) {
        Order order = findOrderOrThrow(id);
        return OrderResponse.from(order);
    }

    @Transactional
    public OrderResponse createOrder(CreateOrderRequest request) {
        Order order = new Order();
        order.setCustomerName(request.getCustomerName());
        order.setProductName(request.getProductName());
        order.setStatus(OrderStatus.PENDING);

        Order saved = orderRepository.save(order);
        log.info("Created order id={}", saved.getId());

        pollingService.forceRefresh();
        return OrderResponse.from(saved);
    }

    @Transactional
    public OrderResponse updateOrder(Long id, UpdateOrderRequest request) {
        Order order = findOrderOrThrow(id);

        if (request.getCustomerName() != null) {
            order.setCustomerName(request.getCustomerName());
        }
        if (request.getProductName() != null) {
            order.setProductName(request.getProductName());
        }
        if (request.getStatus() != null) {
            order.setStatus(OrderStatus.valueOf(request.getStatus()));
        }

        Order saved = orderRepository.save(order);
        log.info("Updated order id={}", saved.getId());

        pollingService.forceRefresh();
        return OrderResponse.from(saved);
    }

    @Transactional
    public void deleteOrder(Long id) {
        Order order = findOrderOrThrow(id);
        orderRepository.delete(order);
        log.info("Deleted order id={}", id);
    }

    private Order findOrderOrThrow(Long id) {
        return orderRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Order not found: " + id));
    }
}