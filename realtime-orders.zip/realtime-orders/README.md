# Real-Time Order Updates — Spring Boot + MySQL + SSE

A production-quality system that pushes database changes to clients **instantly** without client-side polling.

---

## Architecture Overview

```
┌────────────────────────────────────────────────────────────────┐
│                        CLIENTS (Browser / curl)                │
│                    EventSource /api/orders/stream              │
└───────────────────────────┬────────────────────────────────────┘
                            │ SSE (persistent HTTP)
                            │
┌───────────────────────────▼────────────────────────────────────┐
│                     SPRING BOOT SERVICE                         │
│                                                                 │
│  ┌─────────────────────┐    ┌──────────────────────────────┐   │
│  │ OrderChangePolling  │    │      SseEmitterService       │   │
│  │  Service            │───▶│  ConcurrentHashMap of        │   │
│  │                     │    │  SseEmitter per client       │   │
│  │ @Scheduled (1s)     │    │                              │   │
│  │ SELECT * FROM orders│    │  broadcast(event) → all      │   │
│  │ WHERE updated_at >  │    │  active emitters             │   │
│  │ last_watermark      │    └──────────────────────────────┘   │
│  └──────────┬──────────┘                                       │
│             │ JPA query                                        │
└─────────────┼──────────────────────────────────────────────────┘
              │
┌─────────────▼──────────────────────────────────────────────────┐
│                          MySQL                                  │
│   orders table  (INDEX on updated_at ← key for efficiency)     │
└────────────────────────────────────────────────────────────────┘
```

---

## Why This Approach? (Design Thinking)

### Technology: Server-Sent Events (SSE)

| Option       | Pros                          | Cons                              |
|--------------|-------------------------------|-----------------------------------|
| **SSE** ✅   | Native browser support, auto-reconnect, HTTP/1.1 compatible, simple | Server→client only |
| WebSockets   | Bi-directional                | More complex, needs WS upgrade    |
| Long Polling | Simple                        | Wasteful, high latency            |
| Client Poll  | Simplest                      | Hammers the DB, high latency      |

SSE is ideal here because updates flow **server → client** only, which is exactly what the requirement asks for.

### Change Detection: Smart Watermark Polling

Instead of CDC (Debezium/binlog) which requires extra infrastructure, we use an **indexed watermark query**:

```sql
SELECT * FROM orders WHERE updated_at > :lastCheckedAt
```

This is O(changed rows), not O(all rows), because `updated_at` is **indexed**. With 1M rows and 5 changes/second, each poll still returns exactly 5 rows.

### Why not Debezium/binlog?
- Requires `log_bin=ON` in MySQL config (server change)
- Requires `REPLICATION SLAVE` privileges
- Requires running Debezium as a separate service (Kafka or embedded)
- Overkill for a single backend service

For production at scale with millions of rows and hundreds of change/second, Debezium would be the correct choice. The `SseEmitterService` broadcast layer would stay **unchanged**.

---

## Efficiency Features

| Feature | Implementation |
|---|---|
| Only changed rows fetched | `WHERE updated_at > watermark` with INDEX |
| Skip broadcast if no clients | Early return when `emitters.isEmpty()` |
| No replay on restart | Watermark initialised to `MAX(updated_at)` |
| Memory-leak-free connections | `onCompletion/onTimeout/onError` callbacks remove dead emitters |
| Keep-alive | Heartbeat every 15 s prevents proxy timeouts |
| Instant write feedback | `forceRefresh()` nudges watermark after write |
| Delete detection | Separate 5-second cycle (less frequent than updates) |

---

## Prerequisites

- Java 17+
- Maven 3.8+
- MySQL 8.x

---

## Setup & Run

### 1. MySQL

```bash
mysql -u root -p < src/main/resources/schema.sql
```

### 2. Configure credentials

Edit `src/main/resources/application.properties`:

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/orders_db?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true
spring.datasource.username=root
spring.datasource.password=YOUR_PASSWORD
```

### 3. Build & Run

```bash
mvn spring-boot:run
```

The service starts on **http://localhost:8080**.

### 4. Open the Browser Client

Open `frontend/index.html` directly in your browser (double-click or `open frontend/index.html`).

---

## API Reference

| Method   | Endpoint                  | Description                           |
|----------|---------------------------|---------------------------------------|
| `GET`    | `/api/orders/stream`      | **SSE stream** — subscribe for events |
| `GET`    | `/api/orders`             | List all orders                       |
| `GET`    | `/api/orders/{id}`        | Get single order                      |
| `POST`   | `/api/orders`             | Create order                          |
| `PATCH`  | `/api/orders/{id}`        | Update order fields                   |
| `DELETE` | `/api/orders/{id}`        | Delete order                          |
| `GET`    | `/api/stats`              | Active SSE connections + health       |

### Create Order

```bash
curl -X POST http://localhost:8080/api/orders \
  -H "Content-Type: application/json" \
  -d '{"customerName":"Alice","productName":"Laptop"}'
```

### Update Status

```bash
curl -X PATCH http://localhost:8080/api/orders/1 \
  -H "Content-Type: application/json" \
  -d '{"status":"SHIPPED"}'
```

### Subscribe via curl (CLI client)

```bash
curl -N http://localhost:8080/api/orders/stream
```

You will see:

```
event: connected
data: Connected. Listening for order changes...

event: order-update
data: {"eventType":"UPDATED","order":{"id":1,"customerName":"Alice","status":"SHIPPED",...},...}
```

---

## SSE Event Format

```json
{
  "eventType": "CREATED | UPDATED | DELETED",
  "order": {
    "id": 1,
    "customerName": "Alice",
    "productName": "Laptop",
    "status": "PENDING",
    "updatedAt": "2024-01-15T10:30:00",
    "createdAt": "2024-01-15T10:00:00"
  },
  "timestamp": "2024-01-15T10:30:01"
}
```

---

## Project Structure

```
realtime-orders/
├── pom.xml
├── frontend/
│   └── index.html                    ← Browser SSE client
└── src/main/
    ├── resources/
    │   ├── application.properties
    │   └── schema.sql
    └── java/com/apt/realtime/
        ├── RealtimeOrdersApplication.java
        ├── model/Order.java              ← JPA entity (indexed on updated_at)
        ├── repository/OrderRepository.java
        ├── dto/OrderDtos.java            ← Request/Response/Event DTOs
        ├── service/
        │   ├── OrderService.java         ← CRUD logic
        │   ├── SseEmitterService.java    ← Connection manager + broadcaster
        │   └── OrderChangePollingService.java ← Watermark-based change detector
        ├── controller/OrderController.java
        └── config/
            ├── WebConfig.java            ← Async + CORS config
            └── GlobalExceptionHandler.java
```

---

## Scaling Path (Production)

1. **Replace polling with Debezium** → reads MySQL binlog, zero DB load for detection
2. **Redis Pub/Sub** → multiple backend instances share SSE broadcasts
3. **Sticky sessions or Redis-backed SSE** → each pod holds its own emitter map, subscribe via Redis channel
